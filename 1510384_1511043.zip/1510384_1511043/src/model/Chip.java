package model;

public class Chip {
	int value;
	
	public Chip(int value) {
		this.value = value;
	}
}
