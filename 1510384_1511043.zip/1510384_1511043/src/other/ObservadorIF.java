package other;

public interface ObservadorIF {
	public void update (int caso, Object obj);
}