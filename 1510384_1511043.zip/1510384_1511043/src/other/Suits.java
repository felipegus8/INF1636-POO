package other;

public enum Suits {
	hearts, spades, diamonds, clubs
}
