package other;

public enum Status {
	hitting,standing;
}
